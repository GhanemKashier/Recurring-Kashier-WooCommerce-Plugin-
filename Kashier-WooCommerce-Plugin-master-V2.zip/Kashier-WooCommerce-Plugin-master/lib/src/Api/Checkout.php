<?php

namespace ITeam\Kashier\Api;

use ITeam\Kashier\Common\KashierResourceModel;
use ITeam\Kashier\Rest\ApiContext;
use ITeam\Kashier\Security\ICipher;
use ITeam\Kashier\Transport\KashierRestCall;

/**
 * Class Checkout
 *
 * Lets you create a new checkout post request.
 *
 * @package ITeam\Kashier\Api
 *
 * @property \ITeam\Kashier\Api\Data\CheckoutRequest $checkoutRequest
 * @property string $status
 * @property array $response
 * @property array error
 */
class Checkout extends KashierResourceModel
{
    const PENDING_STATUS_MAP = [
        'PENDING',
        'AUTHENTICATION_INITIATED',
         'AUTHENTICATION_IN_PROGRESS'
    ];

    /**
     * @param \ITeam\Kashier\Api\Data\CheckoutRequest $checkoutRequest
     *
     * @return Checkout
     */
    public function setCheckoutRequest(\ITeam\Kashier\Api\Data\CheckoutRequest $checkoutRequest)
    {
        $this->checkoutRequest = $checkoutRequest;

        return $this;
    }

    /**
     * Creates and processes a checkout.
     *
     * @param ApiContext $apiContext is the APIContext for this call. It can be used to pass dynamic configuration and credentials.
     * @param ICipher $cipher
     * @param KashierRestCall $restCall is the Rest Call Service that is used to make rest calls
     *
     * @return Checkout
     * @throws \ITeam\Kashier\Exception\KashierConfigurationException
     * @throws \ITeam\Kashier\Exception\KashierConnectionException
     */

         public function requestBody($payLoad)
        {

            var_dump($payLoad);
        $arrayVar = [
            "apiOperation" => "PAY",
            "paymentMethod" => [
                "type" => "CARD",
                "card" => [
                   
                    "cardToken" => $payLoad->cardToken,
                      "save"=> $payLoad->save,
                    "agreement" => [
                        "type" => "RECURRING",
                        "amountVariability" => "VARIABLE",
                        "expiryDate" => "2033-11-11",
                        "maximumAmountPerPayment" => "100000",
                        "minimumDaysBetweenPayments" => "1",
                        "numberOfPayments" => "999",
                        "paymentFrequency" => "DAILY",
                    ],
                ],
            ],
            "order" => [
                "reference" => $payLoad->orderId,
                "amount" => $payLoad->amount,
                "currency" => $payLoad->currency,
                "description" => "order description",
            ],
         
            "interactionSource" => "RECURRING",
            "reconciliation" => [
                "webhookUrl" => add_query_arg('wc-api', "wc_gateway_kashier", home_url('/')),
                "merchantRedirect" => home_url('/'),
                "redirect"=> true,
            ],
            "customer" => ["reference" => $payLoad->shopper_reference],
            "merchantId" => $payLoad->merchantId,
            "timestamp" => "2022-12-15T13:54:01.606Z",
        ];
        if ($payLoad->enable3DS) {
            $arrayVar['paymentMethod']['card']['enable3DS']=$payLoad->enable3DS;
            $arrayVar['interactionSource']="ECOMMERCE";
        }if (isset($payLoad->agreementId)&& $payLoad->agreementId != null) {

            $arrayVar['paymentMethod']['card']['agreement']=["id"=>$payLoad->agreementId];
        }
   return json_encode( $arrayVar) ;

    }

    public function create($apiContext, ICipher $cipher, $restCall = null)
    {
        $this->getCheckoutRequest()
            ->setMerchantId($apiContext->getMerchantId())
            ->setHash($cipher->encrypt());

            $payLoad =( $this-> requestBody( json_decode( $this->getCheckoutRequest()->toJSON())));

        // $payLoad = $this->getCheckoutRequest()->toJSON();
        $json = self::executeCall(
            '/orders',
            'POST',
            $payLoad,
            ["Kashier-Hash"=>$cipher->encrypt()],
            $apiContext,
            $restCall
        ); 

        $this->fromJson($json);

        return $this;
    }

    /**
     * @return \ITeam\Kashier\Api\Data\CheckoutRequest
     */
    public function getCheckoutRequest()
    {
        return $this->checkoutRequest;
    }
 
    public function isSuccess()
    {
        $response = $this->getResponse();
            var_dump("143 143 ");
            var_dump($response["result"]);

        if (isset($response['result'])) {
            return strtoupper($response['result']) === 'SUCCESS' && ( isset($response["transactionResponseCode"]) && $response["transactionResponseCode"]=='00');
        }

        return false;
    }

    public function isPending()
    {
        var_dump("144");
        $responseData = $this->getResponse();
        var_dump($responseData["transactionResponseCode"]);

        return in_array($this->getStatus(), self::PENDING_STATUS_MAP)
            || (isset($responseData["transactionResponseCode"]) && in_array($responseData["transactionResponseCode"], self::PENDING_STATUS_MAP));
    }

    public function is3DsRequired()
    {
        $responseData = $this->getResponse();
        var_dump($this->isPending());
        var_dump("156");
        return $this->isPending();
    }

    /**
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @return array
     */
    public function getResponse()
    {
        return $this->response;
    }

    /**
     * @return array
     */
    public function getMessages()
    {
        return $this->messages;
    }

    public function getErrorMessage()
    {
        $responseData = $this->getResponse();
        $errorMessages = $this->getMessages();

        if (isset($errorMessages['en'])) {
            return $errorMessages['en'];
        }

        if (isset($responseData['messages']['en'])) {
            return $responseData['messages']['en'];
        }
    }

}
