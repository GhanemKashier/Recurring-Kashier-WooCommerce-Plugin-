/* global wc_kashier_params */
jQuery(function ($) {
    'use strict';
    var wc_kashier_3ds = {
      $body: $('body'),
  
      init: function () {

       

        wc_kashier_3ds._init3DsListener();
      },
      _init3DsListener: function () {
        if (window.addEventListener) {
          addEventListener(
            'message',
            wc_kashier_3ds._3DsFrameMessageListener,
            false
          );
        } else {
          attachEvent('onmessage', wc_kashier_3ds._3DsFrameMessageListener);
        }
  
        if (wc_kashier_params.is_order_pay_page === '1') {
          $('#el-kashier-button').click();
        }
      },
      _3DsFrameMessageListener: function (e) {
        var iFrameMessage = e.data;
        console.log(iFrameMessage);
        // noinspection EqualityComparisonWithCoercionJS
        console.log(iFrameMessage.message);


        if (iFrameMessage.message == 'contentLoaded') {
          wc_kashier_3ds.$body.addClass('kashier-processing').block({
            message: null,
            overlayCSS: {
              background: '#fff',
              opacity: 0.6,
            },
          });
        }
        if (iFrameMessage.message == 'closeIframe') {
          wc_kashier_3ds.$body.addClass('kashier-processing').unblock();
        }
  console.log(iFrameMessage.params.body.status );
        if (iFrameMessage.params.body.status == 'SUCCESS' ) {
          console.log(iFrameMessage.message);
          window.location = wc_kashier_params.return_url+"&status=SUCCESS";
        //   iFrameMessage.params.order_key = wc_kashier_params.current_order_key;
          console.log(wc_kashier_params.current_order_key);

        }else
        {
          window.location = wc_kashier_params.return_url+"&status=FAILURE";

       //   window.location = wc_kashier_params.return_url;

        }
      },
      _showError: function (errorMessage) {
        $(
          '.woocommerce-NoticeGroup-kashier, .woocommerce-error, .woocommerce-message'
        ).remove();
        wc_kashier_3ds.$woocommerceNoticesWrapper.prepend(
          '<div class="woocommerce-NoticeGroup woocommerce-NoticeGroup-kashier"><div class="woocommerce-error"> ' +
            errorMessage +
            '</div></div>'
        );
      },
    };
    wc_kashier_3ds.init();
  });